[![Build Status](https://travis-ci.com/HighDeveloper/disciple-tools-third-party-authentication-plugin.svg?branch=master)](https://travis-ci.com/HighDeveloper/disciple-tools-third-party-authentication-plugin)

# Disciple Tools Third Party Authentication Plugin
The Disciple Tools Third Party Authentication Plugin is a plugin created to allow the user to connect the Disciple Tools instance using several authentication methods like Microsoft Azure .etc.
