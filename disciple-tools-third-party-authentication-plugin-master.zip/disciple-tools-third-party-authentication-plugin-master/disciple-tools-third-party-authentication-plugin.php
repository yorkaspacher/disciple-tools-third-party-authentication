<?php

/**
 * Plugin Name: Disciple Tools - Third Party Authentication
 * Plugin URI: https://github.com/HighDeveloper/disciple-tools-third-party-authentication-plugin
 * Description: Disciple Tools - Third Party Authentication is a plugin created to allow the user to connect the Disciple Tools instance using several authentication methods like Microsoft Azure .etc.
 * Version:  0.1.0
 * Author URI: https://github.com/HighDeveloper
 * GitHub Plugin URI: https://github.com/HighDeveloper/disciple-tools-third-party-authentication-plugin
 * Requires at least: 4.7.0
 * (Requires 4.7+ because of the integration of the REST API at 4.7 and the security requirements of this milestone version.)
 * Tested up to: 5.4
 *
 * @package High_Developer
 * @link    https://github.com/HighDeveloper
 * @license GPL-2.0 or later
 *          https://www.gnu.org/licenses/gpl-2.0.html
 */

/**
 * Refactoring (renaming) this plugin as your own:
 * 1. @todo Refactor all occurrences of the name DT_Third_Party_Authentication, dt_third_party_authentication, dt-third-party-authentication, third-party-authentication-plugin, tp_post_type, and Third Party Authentication Plugin
 * 2. @todo Rename the `disciple-tools-third-party-authentication-plugin.php and menu-and-tabs.php files.
 * 3. @todo Update the README.md and LICENSE
 * 4. @todo Update the default.pot file if you intend to make your plugin multilingual. Use a tool like POEdit
 * 5. @todo Change the translation domain to in the phpcs.xml your plugin's domain: @todo
 * 6. @todo Replace the 'sample' namespace in this and the rest-api.php files
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
$dt_third_party_authentication_required_dt_theme_version = '0.28.0';

/**
 * Gets the instance of the `DT_Third_Party_Authentication_Plugin` class.
 *
 * @since  0.1
 * @access public
 * @return object|bool
 */
function dt_third_party_authentication_plugin()
{
    global $dt_third_party_authentication_required_dt_theme_version;
    $wp_theme = wp_get_theme();
    $version = $wp_theme->version;

    /*
     * Check if the Disciple.Tools theme is loaded and is the latest required version
     */
    $is_theme_dt = strpos($wp_theme->get_template(), "disciple-tools-theme") !== false || $wp_theme->name === "Disciple Tools";
    if ($is_theme_dt && version_compare($version, $dt_third_party_authentication_required_dt_theme_version, "<")) {
        add_action('admin_notices', 'DT_Third_Party_Authentication_Plugin_hook_admin_notice');
        add_action('wp_ajax_dismissed_notice_handler', 'dt_hook_ajax_notice_handler');
        return false;
    }
    if (!$is_theme_dt) {
        return false;
    }
    /**
     * Load useful function from the theme
     */
    if (!defined('DT_FUNCTIONS_READY')) {
        require_once get_template_directory() . '/dt-core/global-functions.php';
    }
    /*
     * Don't load the plugin on every rest request. Only those with the 'sample' namespace
     */
    $is_rest = dt_is_rest();
    //@todo change 'sample' if you want the plugin to be set up when using rest api calls other than ones with the 'sample' namespace
    if (!$is_rest) {
        return DT_Third_Party_Authentication_Plugin::get_instance();
    }
    // @todo remove this "else if", if not using rest-api.php
    else if (strpos(dt_get_url_path(), 'dt_third_party_authentication_plugin') !== false) {
        return DT_Third_Party_Authentication_Plugin::get_instance();
    }
    // @todo remove if not using a post type
    else if (strpos(dt_get_url_path(), 'tp_post_type') !== false) {
        return DT_Third_Party_Authentication_Plugin::get_instance();
    }
}
add_action('after_setup_theme', 'dt_third_party_authentication_plugin');

add_action('login_footer', array('dt_third_party_authentication_plugin', 'render_login_button'), 20, 3);
add_action('wp_enqueue_scripts', array('dt_third_party_authentication_plugin', 'o365_load_scripts'));
add_action('wp_ajax_update_user_activity', array('dt_third_party_authentication_plugin', 'o365_update_user_activity'));
add_action('wp_logout', array('dt_third_party_authentication_plugin', 'o365_logout'));
add_filter("dt_core_public_endpoint_settings", array('dt_third_party_authentication_plugin', 'o365_add_public_settings'));
add_filter('determine_current_user', array('dt_third_party_authentication_plugin', 'o365_determine_current_user'), 20);

// DETECT USER LOG IN O365
if (isset($_GET['code']) && isset($_GET['state']) && $_GET['state'] === "dt_third_party_authentication") {

    // ENABLE get_user_by() WORDPRESS FUNCTION
    include_once ABSPATH . 'wp-includes/pluggable.php';

    // GET USER SESSIONS TOKENS
    $settings = json_decode(get_option('dt_o365_settings'));
    $fields = array("client_id" => $settings->client_id, "redirect_uri" => $settings->redirect_uri, "scope" => $settings->scopes, "code" => $_GET["code"], "grant_type" => "authorization_code", "client_secret" => $settings->client_secret);
    $fields_string = "";
    foreach ($fields as $key => $value) {$fields_string .= $key . "=" . $value . "&";}
    rtrim($fields_string, "&");
    $curl = curl_init();
    if ($curl === false) {
        echo '<div id="login_error">' . apply_filters('login_errors', "<strong>Error</strong>: There is an error trying to initialize 'curl'.") . "</div>\n";
        return new WP_Error('authentication_failed', "There is an error trying to initialize 'curl'.");
    } else {
        curl_setopt_array($curl, array(
            CURLOPT_URL => str_replace('{tenant_id}', $settings->tenant_id, $settings->token_uri),
            CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencoded"),
            CURLOPT_POST => count($fields),
            CURLOPT_POSTFIELDS => $fields_string,
            CURLOPT_RETURNTRANSFER => true,
        ));
        $result = curl_exec($curl);
        if ($result === false) {
            echo '<div id="login_error">' . apply_filters('login_errors', "<strong>Error</strong>: CURL Error (" . curl_errno($curl) . "): '" . curl_error($curl) . "'.") . "</div>\n";
            return new WP_Error('authentication_failed', "There is an error trying to initialize 'curl'.");
        } else {
            $result = json_decode($result);
            $return = array();
            if (property_exists($result, 'error')) {
                $return['error'] = $result;
            } else {
                $return['success'] = $result;
            }
            curl_close($curl);
            if (isset($return['success'])) {
                // CHECK IF O365 RESPONSE ITS CORRECT
                if (isset($return['success']->access_token)) {
                    // Decode 'access_token' to get user email
                    $userProfileInfo = json_decode(base64_decode(str_replace('_', '/', str_replace('-', '+', explode('.', $return['success']->access_token)[1]))));
                    // IF THE USER EXIST, LOGIN IT, OTHERWISE, SHOW A MESSAGE ERROR
                    $userId = email_exists(strtolower($userProfileInfo->upn)); // (personal) email: '' : (organization) upn: ''
                    if ($userId !== false || !is_wp_error($userId)) {
                        $userData = get_user_by('ID', $userId);
                        $userInfo = get_user_by('login', $userData->data->user_login);
                        if ($userInfo) {
                            // SAVE TOKEN AND EXPIRATION DATE AS USER META DATA
                            update_user_meta($userInfo->ID, 'o365_access_token', $return['success']->access_token);
                            update_user_meta($userInfo->ID, 'o365_refresh_token', $return['success']->refresh_token);
                            update_user_meta($userInfo->ID, 'o365_token_expires_in', current_time('timestamp') + intval($return['success']->expires_in)); // timestamp in seconds
                            // LOG IN USER
                            wp_set_current_user($userInfo->ID, $userInfo->data->user_login);
                            wp_set_auth_cookie($userInfo->ID);
                            do_action('wp_login', $userInfo->data->user_login);
                            update_user_meta($userInfo->ID, 'o365_logged', '1');
                            // REDIRECT USER TO PROTECTED VIEW
                            wp_redirect(site_url());
                        } else {
                            echo '<div id="login_error">' . apply_filters('login_errors', "<strong>Error</strong>: Trying to authenticate the user with no success") . "</div>\n";
                            return new WP_Error('authentication_failed', 'Trying to authenticate the user with no success');
                        }
                    } else {
                        echo '<div id="login_error">' . apply_filters('login_errors', "<strong>Error</strong>: There is not a user linked to your email in this site.") . "</div>\n";
                        return new WP_Error('authentication_failed', 'There is not a user linked to your email in this site.');
                    }

                } else {
                    echo '<div id="login_error">' . apply_filters('login_errors', "<strong>Error</strong>: There are not 'access_token' in the response.") . "</div>\n";
                    return new WP_Error('authentication_failed', "There are not 'access_token' in the response.");
                }
            } else if (isset($return['error'])) {
                echo '<div id="login_error">' . apply_filters('login_errors', "<strong>Error</strong>: " . $return['error']->error_description) . "</div>\n";
                return new WP_Error('authentication_failed', $return['error']->error_description);
            }
        }
    }
    exit();
}

/**
 * Singleton class for setting up the plugin.
 *
 * @since  0.1
 * @access public
 */
class DT_Third_Party_Authentication_Plugin
{

    /**
     * Declares public variables
     *
     * @since  0.1
     * @access public
     * @return object
     */
    public $token;
    public $version;
    public $dir_path = '';
    public $dir_uri = '';
    public $img_uri = '';
    public $includes_path;

    /**
     * Returns the instance.
     *
     * @since  0.1
     * @access public
     * @return object
     */
    public static function get_instance()
    {

        static $instance = null;

        if (is_null($instance)) {
            $instance = new dt_third_party_authentication_plugin();
            $instance->setup();
            $instance->includes();
            $instance->setup_actions();
        }
        return $instance;
    }

    /**
     * Constructor method.
     *
     * @since  0.1
     * @access private
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Loads files needed by the plugin.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function includes()
    {
        if (is_admin()) {
            require_once 'includes/admin/admin-menu-and-tabs.php';
        }
    }

    /**
     * Sets up globals.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function setup()
    {

        // Main plugin directory path and URI.
        $this->dir_path = trailingslashit(plugin_dir_path(__FILE__));
        $this->dir_uri = trailingslashit(plugin_dir_url(__FILE__));

        // Plugin directory paths.
        $this->includes_path = trailingslashit($this->dir_path . 'includes');

        // Plugin directory URIs.
        $this->img_uri = trailingslashit($this->dir_uri . 'img');

        // Admin and settings variables
        $this->token = 'dt_third_party_authentication_plugin';
        $this->version = '0.1';

        // sample rest api class
        //require_once 'includes/rest-api.php';

        // sample post type class
        //require_once 'includes/post-type.php';

        // custom site to site links
        //require_once 'includes/custom-site-to-site-links.php';
    }

    /**
     * Sets up main plugin actions and filters.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function setup_actions()
    {

        if (is_admin()) {
            // Check for plugin updates
            if (!class_exists('Puc_v4_Factory')) {
                require get_template_directory() . '/dt-core/libraries/plugin-update-checker/plugin-update-checker.php';
            }
            /**
             * Below is the publicly hosted .json file that carries the version information. This file can be hosted
             * anywhere as long as it is publicly accessible. You can download the version file listed below and use it as
             * a template.
             * Also, see the instructions for version updating to understand the steps involved.
             * @see https://github.com/DiscipleTools/disciple-tools-version-control/wiki/How-to-Update-the-Starter-Plugin
             * @todo enable this section with your own hosted file
             * @todo An example of this file can be found in /includes/admin/disciple-tools-third-party-authentication-plugin-version-control.json
             * @todo It is recommended to host this version control file outside the project itself. Github is a good option for delivering static json.
             */

            /***** @todo remove from here

        $hosted_json = "https://raw.githubusercontent.com/DiscipleTools/disciple-tools-third-party-authentication-plugin/master/includes/admin/version-control.json"; // @todo change this url
        Puc_v4_Factory::buildUpdateChecker(
        $hosted_json,
        __FILE__,
        'disciple-tools-third-party-authentication-plugin'
        );

         ********* @todo to here */
        }

        // Internationalize the text strings used.
        add_action('init', array($this, 'i18n'), 2);

        if (is_admin()) {
            // adds links to the plugin description area in the plugin admin list.
            add_filter('plugin_row_meta', [$this, 'plugin_description_links'], 10, 4);
        }
    }

    /**
     * Filters the array of row meta for each/specific plugin in the Plugins list table.
     * Appends additional links below each/specific plugin on the plugins page.
     *
     * @access  public
     * @param   array       $links_array            An array of the plugin's metadata
     * @param   string      $plugin_file_name       Path to the plugin file
     * @param   array       $plugin_data            An array of plugin data
     * @param   string      $status                 Status of the plugin
     * @return  array       $links_array
     */
    public function plugin_description_links($links_array, $plugin_file_name, $plugin_data, $status)
    {
        if (strpos($plugin_file_name, basename(__FILE__))) {
            // You can still use `array_unshift()` to add links at the beginning.

            $links_array[] = '<a href="https://disciple.tools">Disciple.Tools Community</a>'; // @todo replace with your links.

            // add other links here
        }

        return $links_array;
    }

    /**
     * Method that runs only when the plugin is activated.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public static function activation()
    {

        // Confirm 'Administrator' has 'manage_dt' privilege. This is key in 'remote' configuration when
        // Disciple Tools theme is not installed, otherwise this will already have been installed by the Disciple Tools Theme
        $role = get_role('administrator');
        if (!empty($role)) {
            $role->add_cap('manage_dt'); // gives access to dt plugin options
        }

        $settings = [
            "tenant_id" => "",
            "client_id" => "",
            "redirect_uri" => wp_login_url(),
            "scopes" => "openid offline_access",
            "authorize_uri" => "https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/authorize",
            "client_secret" => "",
            "token_uri" => "https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token",
            "logout_microsoft" => "0",
            "user_logout_uri" => "https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/logout?post_logout_redirect_uri=" . wp_login_url(),
        ];

        add_option('dt_o365_settings', json_encode($settings));
    }

    public static function render_login_button()
    {
        $settings = json_decode(get_option('dt_o365_settings'));
        if (!empty($settings->tenant_id) && !empty($settings->client_id) && !empty($settings->client_secret)) {
            ?>
                <a class="loginLink" href="<?php echo str_replace('{tenant_id}', $settings->tenant_id, $settings->authorize_uri) . "?client_id=" . $settings->client_id . "&redirect_uri=" . $settings->redirect_uri . "&scope=" . $settings->scopes . "&response_type=code&response_mode=query&state=dt_third_party_authentication"; ?>"></a>
                <style>
                    .loginLink {
                        background-image: none,url(<?php echo plugin_dir_url(__FILE__) . '0365_login_link.svg'; ?>);
                        background-repeat: no-repeat;
                        display: block;
                        margin-left: auto;
                        margin-right: auto;
                        margin-top: 30px;
                        width: 215px;
                        height: 41px;
                    }
                </style>
            <?php
}
    }

    public static function o365_load_scripts()
    {
        if (is_user_logged_in()) {
            global $current_user;
            $o365Logged = get_user_meta($current_user->ID, 'o365_logged', true);
            $settings = json_decode(get_option('dt_o365_settings'));
            // ONLY ADD SCRIPTS IF THE USER LOGGED USING 0365 CREDENTIALS
            if ($o365Logged == "1") {
                wp_enqueue_script('detect-user-inactivity', plugin_dir_url(__FILE__) . 'includes/js/user-inactivity.js', array('jquery'), false, true);
                wp_localize_script('detect-user-inactivity', 'settings', array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'timeout' => 300, //SAVE IN ADMIN SETTING (SECONDS)
                    'user_logout_uri' => str_replace('{tenant_id}', $settings->tenant_id, $settings->user_logout_uri),
                    'home_url' => home_url(),
                ));
            }
        }
    }

    public static function o365_update_user_activity()
    {
        if (isset($_POST) && is_user_logged_in()) {
            global $current_user;

            $userIsActive = sanitize_text_field($_POST['user_is_active']);
            $userTokenExpiration = (int) get_user_meta($current_user->ID, 'o365_token_expires_in', true);
            $tokenExpired = (current_time('timestamp') > $userTokenExpiration);

            if ($tokenExpired) {
                $settings = json_decode(get_option('dt_o365_settings'));
                if ($userIsActive == "1") {
                    //Update token
                    $refreshToken = get_user_meta($current_user->ID, 'o365_refresh_token', true);

                    if (!empty($refreshToken)) {
                        $fields = array("client_id" => $settings->client_id, "scope" => $settings->scopes, "refresh_token" => $refreshToken, "grant_type" => "refresh_token", "client_secret" => $settings->client_secret);
                        $fields_string = "";
                        foreach ($fields as $key => $value) {$fields_string .= $key . "=" . $value . "&";}
                        rtrim($fields_string, "&");
                        $curl = curl_init();
                        curl_setopt_array($curl, array(
                            CURLOPT_URL => str_replace('{tenant_id}', $settings->tenant_id, $settings->token_uri),
                            CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencoded"),
                            CURLOPT_POST => count($fields),
                            CURLOPT_POSTFIELDS => $fields_string,
                            CURLOPT_RETURNTRANSFER => true,
                        ));
                        $result = curl_exec($curl);
                        $result = json_decode($result);
                        $return = array();
                        if (property_exists($result, 'error')) {
                            $return['error'] = $result;
                        } else {
                            $return['success'] = $result;
                        }
                        curl_close($curl);

                        if (isset($return['success'])) {
                            // CHECK IF O365 RESPONSE ITS CORRECT
                            if ($return['success']->access_token) {
                                update_user_meta($current_user->ID, 'o365_access_token', $return['success']->access_token);
                                update_user_meta($current_user->ID, 'o365_refresh_token', $return['success']->refresh_token);
                                update_user_meta($current_user->ID, 'o365_token_expires_in', current_time('timestamp') + intval($return['success']->expires_in)); // timestamp in seconds
                            } else {
                                echo '<div id="login_error">' . apply_filters('login_errors', "<strong>Error</strong>: " . $return['error']->error_description) . "</div>\n";
                                return new WP_Error('authentication_failed', $return['error']->error_description);
                            }
                        } else if (isset($return['error'])) {
                            echo '<div id="login_error">' . apply_filters('login_errors', "<strong>Error</strong>: " . $return['error']->error_description) . "</div>\n";
                            return new WP_Error('authentication_failed', $return['error']->error_description);
                        }

                    }
                } else if ($userIsActive == "0") {
                    // Log out user
                    wp_logout();
                }
            }
        }
    }

    public static function o365_logout($userId)
    {
        $o365Logged = get_user_meta($userId, 'o365_logged', true);
        $settings = json_decode(get_option('dt_o365_settings'));
        if ($o365Logged == "1" && $settings->logout_microsoft == "1") {
            // Reset user meta
            update_user_meta($userId, 'o365_logged', '0');
            update_user_meta($userId, 'o365_access_token', '');
            update_user_meta($userId, 'o365_refresh_token', '');
            update_user_meta($userId, 'o365_token_expires_in', '');
            wp_redirect(str_replace('{tenant_id}', $settings->tenant_id, $settings->user_logout_uri));
            exit();
        }
    }

    public static function o365_add_public_settings($settings)
    {
        $o365Settings = json_decode(get_option('dt_o365_settings'));
        unset($o365Settings->redirect_uri);
        unset($o365Settings->logout_microsoft);
        $settings['login_settings']['microsoft'] = $o365Settings;
        return $settings;
    }

    // Hook used to let the users log in in the Mobile App using the o365 auth method
    public static function o365_determine_current_user($userId)
    {
        if ($userId == false) {
            $headerToken = null;
            if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
                $headerToken = sanitize_text_field(wp_unslash($_SERVER['HTTP_AUTHORIZATION']));
            }/* elseif (function_exists("apache_request_headers") && isset(apache_request_headers()['Authorization'])) {
                $headerToken = sanitize_text_field(wp_unslash(apache_request_headers()['Authorization']));
            } elseif (function_exists("apache_request_headers") && isset(apache_request_headers()['authorization'])) {
                $headerToken = sanitize_text_field(wp_unslash(apache_request_headers()['authorization']));
            }*/
            if ($headerToken) {
                $token = str_replace('Bearer ', '', $headerToken);
                $decodedToken = json_decode(base64_decode(str_replace('_', '/', str_replace('-', '+', explode('.', $token)[1]))));
                $userId = email_exists(strtolower($decodedToken->upn)); // (personal) email: '' : (organization) upn: ''
            }
        }
        return $userId;
    }

    /**
     * Method that runs only when the plugin is deactivated.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public static function deactivation()
    {
        delete_option('dismissed-dt-third-party-authentication');
        delete_option('dt_o365_settings');
    }

    /**
     * Loads the translation files.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function i18n()
    {
        load_plugin_textdomain('dt_third_party_authentication_plugin', false, trailingslashit(dirname(plugin_basename(__FILE__))) . 'languages');
    }

    /**
     * Magic method to output a string if trying to use the object as a string.
     *
     * @since  0.1
     * @access public
     * @return string
     */
    public function __toString()
    {
        return 'dt_third_party_authentication_plugin';
    }

    /**
     * Magic method to keep the object from being cloned.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function __clone()
    {
        _doing_it_wrong(__FUNCTION__, 'Whoah, partner!', '0.1');
    }

    /**
     * Magic method to keep the object from being unserialized.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function __wakeup()
    {
        _doing_it_wrong(__FUNCTION__, 'Whoah, partner!', '0.1');
    }

    /**
     * Magic method to prevent a fatal error when calling a method that doesn't exist.
     *
     * @param string $method
     * @param array $args
     * @return null
     * @since  0.1
     * @access public
     */
    public function __call($method = '', $args = array())
    {
        _doing_it_wrong("dt_third_party_authentication_plugin::" . esc_html($method), 'Method does not exist.', '0.1');
        unset($method, $args);
        return null;
    }
}
// end main plugin class

// Register activation hook.
register_activation_hook(__FILE__, ['DT_Third_Party_Authentication_Plugin', 'activation']);
register_deactivation_hook(__FILE__, ['DT_Third_Party_Authentication_Plugin', 'deactivation']);

function DT_Third_Party_Authentication_Plugin_hook_admin_notice()
{
    global $dt_third_party_authentication_required_dt_theme_version;
    $wp_theme = wp_get_theme();
    $current_version = $wp_theme->version;
    $message = __("'Disciple Tools - Third Party Authentication Plugin' plugin requires 'Disciple Tools' theme to work. Please activate 'Disciple Tools' theme or make sure it is latest version.", "dt_third_party_authentication_plugin");
    if ($wp_theme->get_template() === "disciple-tools-theme") {
        $message .= sprintf(esc_html__('Current Disciple Tools version: %1$s, required version: %2$s', 'dt_third_party_authentication_plugin'), esc_html($current_version), esc_html($dt_third_party_authentication_required_dt_theme_version));
    }
    // Check if it's been dismissed...
    if (!get_option('dismissed-dt-third-party-authentication', false)) {?>
        <div class="notice notice-error notice-dt-third-party-authentication is-dismissible" data-notice="dt-third-party-authentication">
            <p><?php echo esc_html($message); ?></p>
        </div>
        <script>
            jQuery(function($) {
                $(document).on('click', '.notice-dt-third-party-authentication .notice-dismiss', function() {
                    $.ajax(ajaxurl, {
                        type: 'POST',
                        data: {
                            action: 'dismissed_notice_handler',
                            type: 'dt-third-party-authentication',
                            security: '<?php echo esc_html(wp_create_nonce('wp_rest_dismiss')) ?>'
                        }
                    })
                });
            });
        </script>
<?php }
}

/**
 * AJAX handler to store the state of dismissible notices.
 */
if (!function_exists("dt_hook_ajax_notice_handler")) {
    function dt_hook_ajax_notice_handler()
    {
        check_ajax_referer('wp_rest_dismiss', 'security');
        if (isset($_POST["type"])) {
            $type = sanitize_text_field(wp_unslash($_POST["type"]));
            update_option('dismissed-' . $type, true);
        }
    }
}
